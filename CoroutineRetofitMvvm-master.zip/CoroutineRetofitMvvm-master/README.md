# CoroutineRetofitMvvm
一个Retrofit+Kotlin Coroutines(协程)+JetPack组件实现的网络请求demo

相较于Retrofit+Rxjava+AutoDispose的方案，本方案更加的简洁，并且也不会内存泄漏，是用Google官方推荐的架构组件实现的
